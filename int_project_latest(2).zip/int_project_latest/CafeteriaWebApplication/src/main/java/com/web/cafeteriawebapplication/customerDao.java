

package com.web.cafeteriawebapplication;

import com.web.cafeteriawebapplication.Customer;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
//
//import com.jtspringproject.JtSpringProject.models.User;


@Repository
public class customerDao {
    //@Autowired
    private SessionFactory sessionFactory;

    public void setSessionFactory(SessionFactory sf) {
        this.sessionFactory = sf;
    }
    @Transactional
    public List<Customer> getAllUser() {
        Session session = this.sessionFactory.getCurrentSession();
        List<Customer>  userList = session.createQuery("from Customer ").list();
        return userList;
    }

    @Transactional
    public Customer saveUser(Customer user) {
        this.sessionFactory.getCurrentSession().saveOrUpdate(user);
        System.out.println("User added" + user.getCustomer_id());
        return user;
    }

    //    public Customer checkLogin() {
//    	this.sessionFactory.getCurrentSession().
//    }
    @Transactional
    public Customer getUser(String username,String password) {
        Query query = sessionFactory.getCurrentSession().createQuery("from Customer where name = :username");
        query.setParameter("username",username);

        try {
            Customer user = (Customer) query.getSingleResult();
            System.out.println(user.getPassword());
            if(password.equals(user.getPassword())) {
                return user;
            }else {
                return new Customer();
            }
        }catch(Exception e){
            System.out.println(e.getMessage());
            Customer user = new Customer();
            return user;
        }

    }

    @Transactional
    public boolean userExists(String username) {
        Query query = sessionFactory.getCurrentSession().createQuery("from Customer where name = :username");
        query.setParameter("username",username);
        return !query.getResultList().isEmpty();
    }
}
