package com.web.cafeteriawebapplication;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@RestController
public class SignupController {




    @Controller
    public class SignUpPageController {

        private final CustomerRepository userRepository;
        private final CustomerServiceClass customerService;

        @Autowired
        public SignUpPageController(CustomerRepository userRepository, CustomerServiceClass customerService) {
            this.userRepository = userRepository;
            this.customerService = customerService;
        }
        @GetMapping(value = "/")
        public String landingPage() {

            return "landing";
        }


        // Display the sign-up page
        @GetMapping("/signup")
        public String getSignUpPage(Model model) {
            model.addAttribute("customer", new Customer());
            return "signup";
        }

        // Handle form submission
        @PostMapping("/signup")
        public String processSignup(
                @ModelAttribute Customer customer,
//                @RequestParam("confirm_password")String confirmPassword,
//                @RequestParam("password") String password,
                Model model
    ){
//        {
//            if (!password.equals(confirmPassword)) {
//                // If passwords do not match, return to the signup page with an error message
//                model.addAttribute("message", "Password and Confirm Password do not match.");
//                return "signup"; // Show the error message on the same page
//            }

            // Save the customer to the database
            userRepository.save(customer);

            // Success message and redirect to login page or another appropriate page
            model.addAttribute("message", "User successfully signed up!");
            return "signup"; // Return to the same page with a success message
        }
        @GetMapping("/login")
        public String userlogin(Model model) {

            return "login";
        }
        @PostMapping("/login")
        public String processLogin(@RequestParam("user") String username,@RequestParam("password")String password,Model model){

            if(customerService.validateUser(username,password)){
                return  "redirect:/#menu";
            }else{
                model.addAttribute("message", "Please enter correct username or password!");
            return "/login";
            }


        }


    }






}
