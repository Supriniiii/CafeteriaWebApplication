package com.web.cafeteriawebapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeteriaWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
